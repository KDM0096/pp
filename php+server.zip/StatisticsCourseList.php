<?PHP
	header("Content-Type : text/html; charset=UTF-8");
	$con = mysqli_connect("localhost", "root", "apmsetup", "mydb2");
	mysqli_set_charset($con,"utf8");  

	$userID = $_GET["userID"];
	
	$result = mysqli_query($con, "SELECT COURSE.crID, COURSE.crGrade, COURSE.crTitle, COURSE.crDivide, COURSE.crPersonnal,
					COUNT(SCHEDULE.crID), COURSE.crCredit FROM SCHEDULE, COURSE WHERE SCHEDULE.crID IN (
					SELECT SCHEDULE.crID FROM SCHEDULE WHERE SCHEDULE.userID = '$userID') AND SCHEDULE.crID = COURSE.crID
					GROUP BY SCHEDULE.crID");

	$response = array();
	
	while($row = mysqli_fetch_array($result)) {
		array_push($response, array("crID"=>$row[0], "crGrade"=>$row[1], "crTitle"=>$row[2], "crDivide"=>$row[3],
			crPersonnal=>$row[4], "COUNT(SCHEDULE.crID)"=>$row[5], "crCredit"=>$row[6]));
	}

	echo json_encode(array("response"=>$response));
	mysqli_close($con);
?>
