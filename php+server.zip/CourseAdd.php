<?PHP
	header("Content-Type: text/html; charset=UTF-8");
	$con = mysqli_connect("localhost", "root", "apmsetup", "mydb2");
	
	$userID = $_POST["userID"];
	$crID = $_POST["crID"];

	$statement = mysqli_prepare($con, "INSERT INTO SCHEDULE VALUE (?, ?)");
	mysqli_stmt_bind_param($statement, "si", $userID, $crID);
	mysqli_stmt_execute($statement);

	$response = array();
	$response["success"] = true;

	echo json_encode($response);
?>