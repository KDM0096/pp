<?PHP
 header("Content-Type: text/html; charset=UTF-8");
 $con = mysqli_connect("localhost", "root", "apmsetup", "mydb2");
 mysqli_set_charset($con,"utf8"); 


 $crYear = $_GET["crYear"];
 $crUniversity = $_GET["crUniversity"];
 $crTerm = $_GET["crTerm"];
 $crArea = $_GET["crArea"];
 $crMajor = $_GET["crMajor"]; 

 $result = mysqli_query($con,"SELECT * FROM COURSE WHERE 
    crUniversity='$crUniversity' AND crYear='$crYear' 
    AND crTerm='$crTerm' AND crArea='$crArea' AND crMajor='$crMajor'");
//$result = mysqli_query($con,"SELECT * FROM COURSE");
 $response = array();
 while($row = mysqli_fetch_array($result)){
 array_push($response, array('crID'=>$row[0], 'crUniversity'=>$row[1], 'crYear'=>$row[2]
    , 'crTerm'=>$row[3], 'crArea'=>$row[4], 'crMajor'=>$row[5]
    , 'crGrade'=>$row[6], 'crTitle'=>$row[7], 'crCredit'=>$row[8]
    , 'crDivide'=>$row[9], 'crPersonnal'=>$row[10], 'crProfessor'=>$row[11]
    , 'crTime'=>$row[12], 'crRoom'=>$row[13]));
 }
 
 echo json_encode(array("response"=>$response));
 mysqli_close($con);
?>