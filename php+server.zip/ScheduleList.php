<?PHP
	header("Content-Type: text/html; charset=UTF-8");
	$con = mysqli_connect("localhost", "root", "apmsetup", "mydb2");
	 mysqli_set_charset($con,"utf8"); 

	$userID = $_GET["userID"];

	$result = mysqli_query($con, "SELECT COURSE.crID, COURSE.crTime, COURSE.crProfessor, COURSE.crTitle, COURSE.crCredit FROM USER, COURSE, SCHEDULE WHERE
 		USER.userID = '$userID' AND USER.userID = SCHEDULE.userID AND SCHEDULE.crID = COURSE.crID");

	$response = array();
	while($row = mysqli_fetch_array($result)) {
	array_push($response, array("crID"=>$row[0], "crTime"=>$row[1], "crProfessor"=>$row[2], "crTitle"=>$row[3], "crCredit"=>$row[4]));
	}

	echo json_encode(array("response"=>$response));
	mysqli_close($con);
?>