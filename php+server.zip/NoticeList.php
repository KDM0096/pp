<?PHP
	$con = mysqli_connect("localhost", "root", "apmsetup", "mydb2");

	mysqli_set_charset($con,"utf8");

	$result = mysqli_query($con, "select * from NOTICE order by notDate desc;");
	$response = array();

	while($row = mysqli_fetch_array($result)){
		array_push($response, array("notContent"=>$row[0], "notName"=>$row[1], "notDate"=>$row[2]));
	}
	
	echo json_encode(array("response"=>$response));
	mysqli_close($con);
?>